import HomeLandingPage from "./home";

export default function Home() {
  return (
    <>
      <HomeLandingPage />
    </>
  );
}
